package com.example.demo.api;

import com.example.demo.model.MxxModel;
import com.example.demo.model.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/happy")
public class HappyController {
    @Autowired
    MxxModel mxx;

    @Autowired
    Task task;

    @GetMapping(value = "/mxx")
    public MxxModel mxx() {
        return mxx;
    }

    @GetMapping(value = "/myyy")
    public String myy() {
        return task.name;
    }

    @GetMapping(value = "/aaa")
    public String test() {
        return "0";
    }

    @GetMapping(value = "/test")
    public String test_2() {
        return "AAA";
    }


    @PostMapping(value = "/mxxx")
    public MxxModel setMxx(@RequestBody MxxModel mxx) {

        mxx.setValue(mxx.getValue() + "testだよ。");
        return mxx;
    }
}