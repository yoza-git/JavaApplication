package org.example;

public class Sample1Before {
    public static void main(String[] args) {
        int a = 10;
        int b = 5;
        int sum1 = a + b;
        System.out.println("Sum1: " + sum1);

        int diff1 = a - b;
        System.out.println("Difference1: " + diff1);

        int x = 15;
        int y = 7;

        int sum2 = x + y;
        System.out.println("Sum2: " + sum2);

        int diff2 = x - y;
        System.out.println("Difference2: " + diff2);
    }
}
