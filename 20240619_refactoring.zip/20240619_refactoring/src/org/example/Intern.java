package org.example;

public class Intern extends Employee {
    public Intern(String name) {
        super(name);
    }

    // Intern 固有のメソッドを追加
}
