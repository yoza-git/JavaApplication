package org.example;

public class Employee {
    private String name;

    public Employee(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    // 共通のメソッドを追加する場合はここに記述
}
