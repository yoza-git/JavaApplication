package org.example;

public class Engineer extends Employee {
    public Engineer(String name) {
        super(name);
    }

    // Engineer 固有のメソッドを追加
}
