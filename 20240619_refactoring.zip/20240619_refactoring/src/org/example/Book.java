package org.example;

public class Book {
        private String title;
        //private AuthorInfo authorInfo;
        //private PublisherInfo publisherInfo;
        private String isbn;
        private double price;

}
