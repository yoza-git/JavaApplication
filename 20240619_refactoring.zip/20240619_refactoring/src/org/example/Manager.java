package org.example;

public class Manager extends Employee {
    public Manager(String name) {
        super(name);
    }

    // Manager 固有のメソッドを追加
}
