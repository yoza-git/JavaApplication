package org.example;

public class Main {
    public static void main(String[] args) {
        Employee engineer = new Engineer("Alice");
        Employee manager = new Manager("Bob");
        Employee intern = new Intern("Charlie");

        System.out.println("Engineer: " + engineer.getName());
        System.out.println("Manager: " + manager.getName());
        System.out.println("Intern: " + intern.getName());
    }
}
