package org.example;

public abstract class Food {
    int price;
    String madeIn;

    abstract String getDetail();

}
