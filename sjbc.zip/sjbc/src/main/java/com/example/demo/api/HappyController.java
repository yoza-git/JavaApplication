package com.example.demo.api;

import com.example.demo.model.MxxModel;
import com.example.demo.model.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController

@RequestMapping(value = "/happy")

public class HappyController {
    @Autowired
    MxxModel mxx;

    @Autowired
    Task task;

    @GetMapping(value = "/mxx")
    public MxxModel mxx() {
        return mxx;
    }

    @GetMapping(value = "/myy")
    public String myy() {
        return task.name;
    }

    @GetMapping(value = "/myy")
    public String test() {
        return "0";
    }

    @PostMapping(value = "/mxx")
    public MxxModel setMxx(@RequestBody MxxModel mxx) {
        mxx.setValue(mxx.getValue());
        return mxx;
    }

}
