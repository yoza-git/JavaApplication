package com.example.sjbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SjbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SjbcApplication.class, args);
	}

}
