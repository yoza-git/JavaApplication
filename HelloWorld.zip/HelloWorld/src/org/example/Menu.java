package org.example;

public class Menu {
    public static final int DRINK_PRICE = 200;
    public static final int MUFFIN_PRICE = 150;
    public static final int BREAD_PRICE = 100;

    public enum Item {
        DRINK, MUFFIN, BREAD
    }

    public static int getPrice(Item item) {
        switch (item) {
            case DRINK:
                return DRINK_PRICE;
            case MUFFIN:
                return MUFFIN_PRICE;
            case BREAD:
                return BREAD_PRICE;
            default:
                return 0;
        }
    }
}

