package org.example;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class echo_Method {

    public static void main(String[]args){
        String today = displayDate("test");
        System.out.println(today);


    }
    //public static void  echo(String str){
    //    System.out.println(str);
    //}
    public static String displayDate(String inputDate){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Calendar calendar = Calendar.getInstance();
        return sdf.format(calendar.getTime());

    }
}
