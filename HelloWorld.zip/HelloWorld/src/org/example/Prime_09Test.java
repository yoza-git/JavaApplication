package org.example;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Prime_09Test {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @org.junit.jupiter.api.Test
    void main() {
    }

    @org.junit.jupiter.api.Test
    void addDay() {
    }

    @Test
    void getPrimeTest(){
        assertEquals(7, Prime_09.getPrime(4));
        assertEquals(11, Prime_09.getPrime(5));
        assertEquals(17, Prime_09.getPrime(7));
    }
}