package org.example;

import java.awt.Point;
import java.lang.String;
import java.sql.Time;
import java.util.Date;

public class sample01 {
    public static void main(String[] args)throws Exception {
        System.out.println(Math.PI);

        Point p = new Point();
        p.x = 10;
        p.y = 20;
        System.out.println(p);

        String str = String.valueOf(20);
        System.out.println(str);

        int a = Integer.parseInt("111");
        System.out.println(a);

        Date date = new Date ();
        long t = date.getTime();
        String s = date.toString();
        System.out.println(t);
        long sec = t / 1000;
        long min = sec /60;
        long hour = min / 60;
        long day = hour /24;
        long year = day / 365;
        System.out.println(year);
        System.out.println(s);

        

    }
}
