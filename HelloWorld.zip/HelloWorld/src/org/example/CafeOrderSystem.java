package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class CafeOrderSystem {
    private List<Order> orders;

    public CafeOrderSystem() {
        this.orders = new ArrayList<>();
    }

    public void addOrder(Order order) {
        orders.add(order);
    }

    public void printOrders() {
        for (Order order : orders) {
            System.out.println("テーブル番号 " + order.getTableNumber() + " (" + order.getCustomerCount() + " 人)");
            for (Map.Entry<Menu.Item, Integer> entry : order.getOrderDetails().entrySet()) {
                System.out.println(" - " + entry.getKey() + ": " + entry.getValue() + " つ");
            }
            System.out.println("合計金額: " + order.calculateTotal() + " 円");
        }
    }

    public static void main(String[] args) {
        CafeOrderSystem system = new CafeOrderSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("テーブル番号 (0-4): ");
            int tableNumber = scanner.nextInt();

            if (tableNumber < 0 || tableNumber > 4) {
                System.out.println("無効なテーブル番号です。もう一度試してください。");
                continue;
            }

            System.out.println("お客様人数: ");
            int customerCount = scanner.nextInt();

            Order order = new Order(tableNumber, customerCount);

            while (true) {
                System.out.println("メニュー項目 (DRINK,MUFFIN,BREAD) を入力、または「done」を入力して終了: ");
                String itemInput = scanner.next().toUpperCase();

                if (itemInput.equals("DONE")) {
                    break;
                }

                try {
                    Menu.Item item = Menu.Item.valueOf(itemInput);

                    System.out.println("数量: ");
                    int quantity = scanner.nextInt();

                    order.addItem(item, quantity);
                } catch (IllegalArgumentException e) {
                    System.out.println("無効な項目です。もう一度試してください。");
                }
            }

            system.addOrder(order);
            System.out.println("注文が正常に追加されました。");

            System.out.println("別の注文を追加しますか? (yes/no): ");
            String continueInput = scanner.next().toLowerCase();

            if (!continueInput.equals("yes")) {
                break;
            }
        }

        system.printOrders();
        scanner.close();
    }
}

