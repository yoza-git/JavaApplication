package org.example;

import java.awt.*;
import java.lang.String;

public class sample02 {


    public static void main(String[] args)throws Exception{
        Point drink = new Point();
        drink.x = 100;
        drink.y = 200;
        Point muffin = new Point();
        muffin.x = 300;
        muffin.y = 400;
        Point bread = new Point();
        bread.x = 500;
        bread.y = 600;

        System.out.println("卓："  );
    }
}
