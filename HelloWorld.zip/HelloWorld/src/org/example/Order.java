package org.example;

import java.util.HashMap;
import java.util.Map;

public class Order {
    private int tableNumber;
    private int customerCount;
    private Map<Menu.Item, Integer> orderDetails;

    public Order(int tableNumber, int customerCount) {
        this.tableNumber = tableNumber;
        this.customerCount = customerCount;
        this.orderDetails = new HashMap<>();
    }

    public void addItem(Menu.Item item, int quantity) {
        orderDetails.put(item, orderDetails.getOrDefault(item, 0) + quantity);
    }

    public int calculateTotal() {
        int total = 0;
        for (Map.Entry<Menu.Item, Integer> entry : orderDetails.entrySet()) {
            total += Menu.getPrice(entry.getKey()) * entry.getValue();
        }
        return total;
    }

    public int getTableNumber() {
        return tableNumber;
    }

    public int getCustomerCount() {
        return customerCount;
    }

    public Map<Menu.Item, Integer> getOrderDetails() {
        return orderDetails;
    }
}

