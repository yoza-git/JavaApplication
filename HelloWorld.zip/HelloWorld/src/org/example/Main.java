package org.example;

public class Main {

    public static void main(String[] args){
        Person p1 = new Person(10);
        Person p2 = new Person(20);
        Person p3 = new Person(30);
        System.out.println(p1.getAge());
        System.out.println(Person.getNumber());
    }
}
