package org.example;

public class Fruits {
    int price;

    String madeIn;

    String color;

    Fruits(int price, String madeIn, String color){
        this.price = price;
        this.madeIn = madeIn;
        this.color = color;
    }

    boolean isMadeInJapan(){
        if(this.madeIn.equals("Japan")){
            return true;
        } else {
            return false;
        }
    }

    String getDetail(){
        return "生産地" + this.madeIn + "色" + this.color;
    }
}
