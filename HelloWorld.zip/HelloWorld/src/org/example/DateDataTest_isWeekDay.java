package org.example;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DateDataTest_isWeekDay {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void setDateData() {
    }

    @Test
    void getDateData() {
    }

    @Test
    void getToday() {
    }

    @Test
    void isToday() {
    }

    @Test
    void isLeapYear() {
    }

    @Test
    void testIsLeapYear() {
    }

    @Test
    void getDaysBetweenDates() {
    }

    @Test
    void validateAndParseDate() {
    }

    /*
    @Test
    void isWeekDay() {
        assertEquals(false, MyDate.isWeekDay("2023/05/14"));
        assertEquals(true, MyDate.isWeekDay("2023/05/15"));
        assertEquals(true, MyDate.isWeekDay("2023/05/16"));
        assertEquals(true, MyDate.isWeekDay("2023/05/17"));
        assertEquals(true, MyDate.isWeekDay("2023/05/18"));
        assertEquals(true, MyDate.isWeekDay("2023/05/19"));
        assertEquals(false, MyDate.isWeekDay("2023/05/20"));

    }*/
}