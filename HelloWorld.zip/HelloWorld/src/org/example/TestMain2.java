package org.example;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TestMain2 {
    public  static void main(String[] args){
        String today = displayDate("2024/04/22");
        System.out.println(today);
    }

    public static String displayDate(String inputDate){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Calendar calendar = Calendar.getInstance();
        try{
            Date d = sdf.parse(inputDate);
            calendar.setTime(d);
        }catch (ParseException e){
            e.printStackTrace();
        }
        return sdf.format(calendar.getTime());

    }
}
